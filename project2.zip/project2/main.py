from pathlib import PurePath, Path
from flask import Flask, flash, render_template, url_for, request, redirect, make_response
from werkzeug.utils import secure_filename


app = Flask(__name__)
app.secret_key = b'5f214cacbd30c2ae4784b520f17912ae0d5d8c16ae98128e3f549546221265e4'

users = {'Ann': "1234", 'Dave': '12345'}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/hello/')
def hello():
    text = f'testing {{url_for}}'
    return text

@app.route('/upload/', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files.get('file')
        file_name = secure_filename(file.filename)
        file.save(PurePath.joinpath(Path.cwd(), 'uploads', file_name))
        return f"Файл {file_name} загружен на сервер"
    return render_template('upload.html')

@app.route('/submit/', methods=['GET', 'POST'])
def submit():
    if request.method == 'POST':
        login = request.form.get('login')
        password = request.form.get('password')
        if login in users.keys() and password == users[login]:
            return 'Welcome!'
        else:
            return 'Something goes wrong! Check out your login and password!'
    return render_template('login.html')

@app.route('/text/', methods=['GET', 'POST'])
def text_count():
    if request.method == 'POST':
        text = request.form.get('input_text')
        return f'{text.count(" ") + 1}'
    return render_template('text.html')

@app.route('/calc/', methods=['GET', 'POST'])
def calc():
    if request.method == 'POST':
        num1 = request.form.get('number1')
        num2 = request.form.get('number2')
        operation = request.form.get('operation')
        match operation:
            case "add":
                return f'{num1} + {num2} = {int(num1) + int(num2)}'
            case "substract":
                return f'{num1} - {num2} = {int(num1) - int(num2)}'
            case "multiply":
                return f'{num1} * {num2} = {int(num1) * int(num2)}'
            case "divide":
                return f'{num1} / {num2} = {int(num1) / int(num2)}' if num2 != 0 else 'ERROR Zero Division'
    return render_template('calc.html')

@app.route('/age/', methods=['GET', 'POST'])
def age():
    if request.method == 'POST':
        name = request.form.get('name')
        age = request.form.get('age')
        if int(age) >= 18:
            return f'Hello, {name}, you are on adult site page'
        else:
            return f'Page cannot be reached'
    return render_template('age.html')

# ЗАДАЧА №7
@app.route('/square/', methods=['GET', 'POST'])
def square():
    if request.method == 'POST':
        num = request.form.get('number')
        return f'{num} * {num} = {int(num) ** 2 }'
    return render_template('square.html')

# ЗАДАЧА №8
@app.route('/hello_name/', methods=['GET', 'POST'])
def hello_name():
    if request.method == 'POST':
        name = request.form.get('name')
        flash(f'hello, {name}', 'success')
        return redirect(url_for('hello_name'))
    return render_template('hello_name.html')

# ЗАДАЧА №9        
@app.route('/email/', methods=['GET', 'POST'])
def email():
    if request.method == 'POST':
        response = make_response("Cookies установлены")
        name = request.form.get('name')
        email = request.form.get('email')
        content = {'name': name }
        response.set_cookie('name', name)
        response.set_cookie('email', email)
        return render_template('hello_name_log.html', **content)
    return render_template('email.html')  

@app.route('/logout/', methods=['GET', 'POST'])
def logout(): 
    if request.method == 'POST':
        response = make_response(render_template('email.html'))
        response.delete_cookie('name')
        response.delete_cookie('email')
        return response
    return render_template('email.html')
    

if __name__ == '__main__':
    app.run(debug=True)
